from django.contrib import admin
from .models import Employee,Department

# Register your models here.
class EmpAdmin(admin.ModelAdmin):
    list_display=['Employee_Number','Employee_Name','Employee_salary','grade','department']
    list_editable=['Employee_salary','Employee_Name','department']
    list_filter=['Employee_salary','department']
    def grade(self,obj):
        if obj.Employee_salary>150000:
            return 'High'
        elif obj.Employee_salary>125000 and obj.Employee_salary<150000:
            return 'Medium'
        else:
            return 'Low'
    def department(self,obj):
        return obj.designation.deptname
admin.site.site_header='Employee Management System'
admin.site.register(Employee,EmpAdmin) # type: ignore
admin.site.register(Department) # type: ignore
