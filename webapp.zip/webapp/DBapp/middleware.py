from django.db.models import Min,Max
from DBapp.models import Employee
class CustomMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    def __call__(self, request):
        if request.method =='POST' and 'search' in request.path:
            print(request.path)
            post_tmp=request.POST.copy()
            if post_tmp['minsal']=='':
                min_sal=Employee.objects.aggregate(Min('Employee_salary'))['Employee_salary__min']#it is subscripting the min(Employee_salary) as it will return a dict
                post_tmp['minsal']=min_sal
                #request.minsal=min_sal
            if post_tmp['maxsal']=='':
                max_sal=Employee.objects.aggregate(Max('Employee_salary'))['Employee_salary__max']#it is subscripting the max(Employee_salary) as it will return a dict
                post_tmp['maxsal']=max_sal
            request.POST=post_tmp    
        response = self.get_response(request)
        return response