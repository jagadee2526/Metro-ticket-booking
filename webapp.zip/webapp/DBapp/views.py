from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Employee,Department

# Create your views here.

def dbprocessing(request):
    return HttpResponse('Processing')

def dbinsert(request):
    if request.method == 'GET':
        depts=Department.objects.all()
        return render(request,'DBapp/insert.html',{'depts':depts})
    if request.method == 'POST':
        eno=int(request.POST['t1'])
        ename=request.POST['t2']
        esal=int(request.POST['t3'])
        edept=int(request.POST.get('dept',1))
        dobj=Department.objects.get(deptno=edept)
    #empobj=Employee(Employee_Number=eno,Employee_Name=ename,Employee_salary=esal)
    #empobj.save()
    try:
        Employee.objects.create(Employee_Number=eno,Employee_Name=ename,Employee_salary=esal,designation=dobj)
    except Exception:
        return render(request,'DBapp/insert.html',{'msg':'failed to insert'})
    return render(request,'DBapp/insert.html',{'msg':'data inserted succesfully'})

def dbselect(request):
    if request.method =='GET':
        emps=Employee.objects.all()
        depts=Department.objects.all()
        return render(request,'dbapp/select.html',{'employees':emps,'depts':depts})



def dbupdate(request,eno):
    if request.method =="GET":
        emp=Employee.objects.get(Employee_Number=eno)
        return render(request,'dbapp/update.html',{'employee':emp})
    if request.method == "POST":

        name=request.POST['ename']
        esal=int(request.POST['esal'])
        edept=int(request.POST['dept'])
        eobj=Employee(Employee_Number=eno,Employee_Name=name,Employee_salary=esal,degination=edept)
        eobj.save()
        return redirect('selecturl')
        


def dbdelete(request,eno):
    if request.method == 'GET':
        emp=Employee.objects.filter(Employee_Number=eno)
        return render(request,'dbapp/delete.html',{'employee':emp})
    if request.method == 'POST':
        Employee.objects.filter(Employee_Number=eno).delete()
        return redirect('selecturl')
    

def dbsearch(request):
    
    if request.method == 'POST':
        
        minsal=int(request.POST['minsal'])
        maxsal=int(request.POST['maxsal'])
        emps=Employee.objects.filter(Employee_salary__range=[minsal,maxsal])
        return render(request,"DBapp/select.html",{'employees':emps})