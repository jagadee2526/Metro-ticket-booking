from django.urls import path
from .import views
urlpatterns=[
    path('',views.dbprocessing),
    path('insert/',views.dbinsert,name='inserturl'),
    path('select/',views.dbselect,name='selecturl'),
    path('modify/<int:eno>/',views.dbupdate,name='updateurl'),
    path('delete/<int:eno>/',views.dbdelete,name='deleteurl'),
    path('search/',views.dbsearch,name='searchurl'),
]