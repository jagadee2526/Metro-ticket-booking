from django.db import models

# Create your models here.
class Department(models.Model):
    deptno=models.IntegerField(primary_key=True)
    deptname=models.CharField(max_length=30) 
    Location=models.CharField(max_length=30)
    def __str__(self):
        return self.deptname

class Employee(models.Model):
    Employee_Number=models.IntegerField(primary_key=True)
    Employee_Name=models.CharField(max_length=30)
    Employee_salary=models.IntegerField()
    designation=models.ForeignKey(Department,null=True,on_delete=models.SET_NULL, related_name='employees_designation')
    email=models.EmailField(null=True)
    department=models.ForeignKey(Department,null=True,on_delete=models.SET_NULL,related_name='employees_department')


class Passport(models.Model):
    passportno=models.CharField(max_length=15)
    issued_date=models.DateField(auto_now=True)

class Human(models.Model):
    personid=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=30)
    address=models.CharField(max_length=100)
    passport=models.OneToOneField(Passport,null=True,on_delete=models.SET_NULL)


class Course(models.Model):
    cid=models.IntegerField(primary_key=True)
    cname=models.CharField(max_length=30)
class Student(models.Model):
    sid=models.IntegerField(primary_key=True)
    name=models.CharField(max_length=30)
    course=models.ManyToManyField(Course)


class Base(models.Model):
    empno=models.IntegerField(primary_key=True)
    empname=models.CharField(max_length=30)
    class Meta:
        abstract=True
class Table1(Base):    
    address=models.CharField(max_length=30)

class Table2(Base):
    mobile=models.CharField(max_length=10)
