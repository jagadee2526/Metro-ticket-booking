from django.shortcuts import render
from .import views
from django.http import HttpResponse,HttpRequest

# Create your views here.
def firstview(request):
    req=isinstance(request,HttpRequest)
    print(req)
    print(request.method)
    return HttpResponse('Hello World')
def secondview(request):
    return HttpResponse('We are learning Django from vcube')