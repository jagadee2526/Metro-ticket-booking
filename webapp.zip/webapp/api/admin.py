from django.contrib import admin
from .models import Stations,Booking

# Register your models here.
admin.site.register(Stations)
admin.site.register(Booking)