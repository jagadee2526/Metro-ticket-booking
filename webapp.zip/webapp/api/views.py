from django.shortcuts import render
from rest_framework.generics import ListAPIView,ListCreateAPIView,RetrieveUpdateDestroyAPIView
from DBapp.models import Employee
from .serializer import EmployeeSerializer,MetroSerializer,UserSerializer
import json
import random
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.authentication import TokenAuthentication
from rest_framework.permissions import IsAuthenticated,IsAdminUser
from rest_framework.authtoken.models import Token
from rest_framework import status
from .models import Stations
from rest_framework.pagination import PageNumberPagination


# Create your views here.
@api_view(['GET','POST'])
@authentication_classes([TokenAuthentication])
@permission_classes([IsAuthenticated])
@permission_classes([IsAdminUser])
def getemployeesapi(request):
    if request.method == 'GET':
        emps=Employee.objects.all()
        serializer_obj=EmployeeSerializer(emps,many=True)
        #create serialiser obj to convert querysets to json
        return Response(serializer_obj.data)
    if request.method == 'POST':
        emp_obj=EmployeeSerializer(data=request.data)
        #create the object fro request data using the serializer
        if emp_obj.is_valid()==True:
            emp_obj.save()
            return Response(status=status.HTTP_200_OK)
        else:
            return Response(emp_obj.errors,status=status.HTTP_400_BAD_REQUEST)
        
@api_view(['GET',"PUT",'DELETE'])

def modifyemployeeapi(request,pk):
    try:
        emp=Employee.objects.get(Employee_Number=pk)
    except Employee.DoesNotExist:
        return Response({"info":"Employee details not existed"},status=status.HTTP_400_BAD_REQUEST)

    if request.method == 'GET':

        # emp=Employee.objects.get(Employee_Number=pk)
        EmployeeSerializer(emp)
        return Response(EmployeeSerializer(emp).data,status=status.HTTP_200_OK)
    if request.method =='PUT':
        s_obj=EmployeeSerializer(emp,data=request.data)
        if s_obj.is_valid()==True:
            s_obj.save()
            return Response(status=status.HTTP_200_OK)
        else:
            return Response(s_obj.erros,status=status.HTTP_400_BAD_REQUEST)
    if request.method == 'DELETE':
        
        emp.delete()
        return Response(status=status.HTTP_200_OK)

def generatetkt(obj):
    f_stid = Stations.objects.get(stname=obj.validated_data['f_station']).stid
    t_stid = Stations.objects.get(stname=obj.validated_data['t_station']).stid
    fare = abs(t_stid - f_stid) * 100  
    
     
    age = obj.validated_data.get('age')           
    if age is not None and age > 50:  
        
        fare =fare * 0.5


    obj.validated_data['fare'] = fare
    obj.validated_data['tktno'] = random.randint(111111, 999999)



@api_view(['POST'])
def bookticketapi(request):
    if request.method =='POST':
        serializer_obj=MetroSerializer(data=request.data)
        # print(serializer_obj)
        if serializer_obj.is_valid()==True:
            generatetkt(serializer_obj)
            booking_obj=serializer_obj.save()
            ticket={
                'tktno':booking_obj.tktno,
                'name':booking_obj.pname,
                "age":booking_obj.age,                
                'from':booking_obj.f_station,
                'to':booking_obj.t_station,
                'fare':booking_obj.fare,
                'date':booking_obj.booking_date

            }
            return Response(ticket,status=status.HTTP_201_CREATED)

        else:
            return Response(serializer_obj.errors,status=status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
def registeruserapi(request):
    serializer_obj=UserSerializer(data=request.data)
    if serializer_obj.is_valid()==True:
        user_obj=serializer_obj.save()
        #to encrpt the password to save in the database
        user_obj.set_password(serializer_obj.validated_data['password'])
        user_obj.save()
        token_obj=Token.objects.create(user=user_obj)
        credentials={
            "username":user_obj.username,
            "token":token_obj.key
        }
        return Response(credentials,status=status.HTTP_201_CREATED)
    else:
        return Response(serializer_obj.errors,status=status.HTTP_400_BAD_REQUEST)


#to display the data using class based views
# class GetEmpClassApi(APIView):
#     def get(self,request):
#         emps=Employee.objects.all()
#         serializer_obj=EmployeeSerializer(emps,many=True)
#         return Response(serializer_obj.data,status=status.HTTP_200_OK)

#to display the paginated data using class based views
class GetEmpClassApi(APIView):
    #to make it secure api
    #authentication_classes=[TokenAuthentication]
    #permission_classes=[IsAuthenticated]
    def get(self,request):
        emps=Employee.objects.all()
        paginator=PageNumberPagination()
        paginator.page_size=2
        page_data=paginator.paginate_queryset(emps,request)
        serializer_obj=EmployeeSerializer(page_data,many=True)
        return paginator.get_paginated_response(serializer_obj.data)
    
    def post(self,request):
        serializer_obj=EmployeeSerializer(data=request.data)
        if serializer_obj.is_valid()==True:
            serializer_obj.save()
            return Response(serializer_obj.data,status=status.HTTP_201_CREATED)
        else:
            return Response(serializer_obj.errors,status=status.HTTP_400_BAD_REQUEST)
#to display the data using generic views    
class GetEmpGenericApi(ListAPIView):
    queryset=Employee.objects.all() 
    serializer_class=EmployeeSerializer


# List all employees (GET) and create a new employee (POST)
class GetEmpGenericApi(ListCreateAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer

#to put,fetch,update and delete the data using generic views
class EmpDetailGenericApi(RetrieveUpdateDestroyAPIView):
    queryset = Employee.objects.all()
    serializer_class = EmployeeSerializer