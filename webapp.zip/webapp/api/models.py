from django.db import models

# Create your models here.
class Stations(models.Model):
    stid=models.IntegerField(primary_key=True)
    stname=models.CharField(max_length=30)

class Booking(models.Model):
    tktno=models.IntegerField(primary_key=True)
    pname=models.CharField(max_length=20)
    age=models.IntegerField(null=True)
    f_station=models.CharField(max_length=30)
    t_station=models.CharField(max_length=30)
    fare=models.IntegerField()
    booking_date=models.DateField(auto_now=True)