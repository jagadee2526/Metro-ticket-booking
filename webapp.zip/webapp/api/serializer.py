from rest_framework.serializers import ModelSerializer
from DBapp.models import Employee,Department
from rest_framework import serializers
from .models import Stations,Booking
from django.contrib.auth.models import User
from rest_framework.pagination import PageNumberPagination
class DeptSeralizer(serializers.ModelSerializer):
       class Meta:
           model=Department
           fields='__all__'
class EmployeeSerializer(serializers.ModelSerializer):
    #designation=DeptSeralizer()
    class Meta:
        model=Employee
        fields=['Employee_Number','Employee_Name','Employee_salary','designation']

    def validate_designation(self, value):
        if isinstance(value, int):  
            return Department.objects.get(deptno=value)
        return value

    def create(self, validated_data):
        # return Employee.objects.create(**validated_data)
        dname=validated_data['designation']
        dobj=Department.objects.get(deptname=dname) 
        eobj=Employee.objects.create(Employee_Number=validated_data['Employee_Number'],Employee_Name=validated_data['Employee_Name'],Employee_salary=validated_data['Employee_salary'],designation=dobj)
        return eobj
    
    def validate_Employee_salary(self,value):
        if value<0:
            raise serializers.ValidationError("salary can't be negative")
        return value
    

class MetroSerializer(serializers.Serializer):
    name=serializers.CharField(max_length=20)
    age=serializers.IntegerField(required=True)
    f_station=serializers.CharField(max_length=20)
    t_station=serializers.CharField(max_length=20)  

    def  validate_age(self,age):
        if age<18:
            raise serializers.ValidationError('Age should be greater than 18')
        return age
            #take the station name asthe name given for station in Stations table
    def validate_f_station(self,fstation):
        station=Stations.objects.filter(stname=fstation)
        if len(station)==0:
            raise serializers.ValidationError(str(fstation)+"station is not available")
        return fstation
    
    def validate_t_station(self,tstation):
        station=Stations.objects.filter(stname=tstation)
        if len(station)==0:
            raise serializers.ValidationError(str(tstation)+"selected station is not availabe")
        return tstation
    
    # creates a booking object and stores it in database.
    # This function uses validated data from serializer to create a booking object
    # and then stores it in database. it returns the created booking object
    #take the station name asthe name given for station in booking table
    def create(self, validated_data):  
        bobj=Booking.objects.create(tktno=validated_data['tktno'],\
        pname=validated_data['name'],f_station=validated_data['f_station'],\
            age=validated_data['age'],\
            t_station=validated_data['t_station'],fare=validated_data['fare'])
        return bobj
        



class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=['username','password','email']
