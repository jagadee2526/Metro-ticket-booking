from django.shortcuts import render,HttpResponse,redirect
from django.contrib.auth import authenticate,login as auth_login,logout as auth_logout
from django.contrib.auth.forms import UserCreationForm

# Create your views here.
def login(request):
    if request.method == 'GET':
        return render(request,'Authentication/login.html')
    
    if request.method=='POST':
        uname=request.POST['uname']
        pwd=request.POST['pass']

        valid_user=authenticate(request,username=uname,password=pwd)
        if valid_user is  None:
            return render(request,'Authentication/login.html',{'msg':'wrong_credentials'})
        else:
            auth_login(request, valid_user)

            return HttpResponse('Login success')
        

def logout(request):
    auth_logout(request)
    return redirect('login_url')

def signup(request):
    if request.method == 'GET':
        empty_form=UserCreationForm()
        return render(request,'Authentication/signup.html',{'form':empty_form})
    
    if request.method == 'POST':
        dataform=UserCreationForm(request.POST)
        if dataform.is_valid() == True:
            dataform.save()
            return redirect('login_url')        
        else:
            return render(request,'Authentication/signup.html',{'form':dataform})