from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def calculator(request):
    return HttpResponse('Calculator')

def addition(request):
    if request.method == 'GET':
        return render (request,'calculator/addition.html')
    if request.method =='POST':
        print(request.POST)
        t1=int(request.POST['t1'])
        t2=int(request.POST['t2'])
        if 'add' in request.POST:
            t=t1+t2
            action='addition'
        elif 'subs' in request.POST:
            t=t2-t1
            action ='subs'
        elif 'multi' in request.POST:
            t=t1*t2
            action ='multi'
        else :
            t=t2/t1
            action='division'
        return render(request,'calculator/addition.html',{'result':t,'action':action})
def mtable(request):
    if request.method =='GET':
        return render(request,'calculator/mtable.html')
    if request.method =='POST':
        num=int(request.POST['t1'])
        output=[]
        for i in range(1,21):
            output.append(str(i)+'*'+str(num)+'='+str(i*num))
        return render(request,'calculator/mtable.html',{'table':output})
          